# -*- coding: utf-8 -*-
"""
Extracts the ORIGINAL (decompressed) code.bin from a decrypted 3DS ROM.

Usage:  python extract_code.py "Super Robot Wars UX.3ds"
Output: code_original.bin (next to the ROM)

Accepts .3ds / .cci (NCSD) and .cxi (NCCH). The ROM must be decrypted.
The ROM is only read, never modified.
"""
import struct, sys, os

MEDIA = 0x200

def read_at(f, off, n):
    f.seek(off)
    return f.read(n)

def blz_decompress(data):
    """Backwards LZ decompression of the 3DS .code section."""
    if len(data) < 8:
        return bytes(data)
    off_hdr, inc_len = struct.unpack_from("<II", data, len(data) - 8)
    if inc_len == 0:
        return bytes(data)          # not compressed
    hdr_len = off_hdr >> 24
    enc_len = off_hdr & 0xFFFFFF
    in_len = len(data)
    dec_len = in_len + inc_len
    out = bytearray(dec_len)
    out[:in_len] = data
    in_cur = in_len - hdr_len
    out_cur = dec_len
    in_end = in_len - enc_len
    while in_cur > in_end:
        in_cur -= 1
        flags = data[in_cur]
        for _ in range(8):
            if in_cur <= in_end:
                break
            if flags & 0x80:
                in_cur -= 2
                v = data[in_cur] | (data[in_cur + 1] << 8)
                ln = (v >> 12) + 3
                disp = (v & 0x0FFF) + 3
                if ln > out_cur - in_end:
                    ln = out_cur - in_end
                for _ in range(ln):
                    out_cur -= 1
                    out[out_cur] = out[out_cur + disp]
            else:
                in_cur -= 1
                out_cur -= 1
                out[out_cur] = data[in_cur]
            flags = (flags << 1) & 0xFF
    return bytes(out)

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    rom = sys.argv[1]
    with open(rom, "rb") as f:
        magic = read_at(f, 0x100, 4)
        if magic == b"NCSD":
            p0_off, p0_size = struct.unpack("<II", read_at(f, 0x120, 8))
            ncch = p0_off * MEDIA
        elif magic == b"NCCH":
            ncch = 0
        else:
            sys.exit("Unrecognized file (not NCSD or NCCH). Is it a .cia? This script cannot read that format.")
        hdr = read_at(f, ncch, 0x200)
        if hdr[0x100:0x104] != b"NCCH":
            sys.exit("Could not find the game partition (NCCH).")
        flags7 = hdr[0x18F]
        if not (flags7 & 0x04):
            print("WARNING: the ROM seems to be ENCRYPTED (NoCrypto flag missing). The output will not be usable.")
        exefs_off = struct.unpack_from("<I", hdr, 0x1A0)[0] * MEDIA + ncch
        exefs_hdr = read_at(f, exefs_off, 0x200)
        code = None
        for i in range(10):
            name, off, size = struct.unpack_from("<8sII", exefs_hdr, i * 16)
            if name.rstrip(b"\0") == b".code":
                code = read_at(f, exefs_off + 0x200 + off, size)
        if code is None:
            sys.exit("Could not find .code inside the ExeFS.")
    dec = blz_decompress(code)
    out = os.path.join(os.path.dirname(os.path.abspath(rom)), "code_original.bin")
    with open(out, "wb") as g:
        g.write(dec)
    print(f"Compressed .code: {len(code):,} bytes -> decompressed: {len(dec):,} bytes")
    print(f"Written: {out}")

if __name__ == "__main__":
    main()
